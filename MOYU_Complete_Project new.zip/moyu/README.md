# MOYU — Career Compass

MOYU is a MERN-style career exploration app for students. It includes email/password accounts, seven career domains, a four-section interest assessment, ranked domain recommendations, roadmaps with saved task completion, free learning resources, a dashboard, and an AI career mentor endpoint.

## Project structure

- `client/` — React + Vite frontend
- `server/` — Express API + MongoDB/Mongoose backend

## Run locally

Requirements: Node.js 18.18+ and a MongoDB Atlas database (or local MongoDB).

1. Open a terminal in `server/` and install packages:

   ```bash
   npm install
   cp .env.example .env
   ```

2. Edit `server/.env` and set `MONGODB_URI`, a long random `JWT_SECRET`, `CLIENT_ORIGIN=http://localhost:5173`, and `NODE_ENV=development`. `OPENAI_API_KEY` is optional; without it the mentor shows a clearly labelled fallback response.

3. Start the API from `server/`:

   ```bash
   npm run dev
   ```

4. Open a second terminal in `client/`:

   ```bash
   npm install
   cp .env.example .env
   npm run dev
   ```

5. Visit `http://localhost:5173`. Register a new account. API health check: `http://localhost:5000/api/health`.

## Deploy for free / low cost

See `DEPLOYMENT.md` for the step-by-step Vercel + Render + MongoDB Atlas setup. Free-tier limits and provider policies can change, and free backend services may sleep when idle.

## Environment variables

### Backend (`server/.env` or Render environment)

- `PORT` — provided automatically by Render; local default is 5000.
- `MONGODB_URI` — MongoDB Atlas connection string.
- `JWT_SECRET` — long random secret; never expose it to the frontend.
- `JWT_EXPIRES_IN` — e.g. `7d`.
- `CLIENT_ORIGIN` — exact frontend origin, no trailing slash (local: `http://localhost:5173`).
- `NODE_ENV` — `production` on Render.
- `OPENAI_API_KEY` — optional, for live AI mentor responses. This key can incur usage charges; set provider limits before using it.
- `OPENAI_MODEL` — optional, defaults to `gpt-4o-mini`.
- `OPENAI_BASE_URL` — optional, defaults to the OpenAI chat completions endpoint.

### Frontend (`client/.env` or Vercel environment)

- `VITE_API_BASE_URL` — API base URL ending in `/api`; local default is `http://localhost:5000/api`.

## Important notes

- Passwords are stored as bcrypt hashes; the API uses an HTTP-only session cookie.
- Never commit `.env` files or share API keys/database credentials.
- The AI mentor only uses a live AI provider when `OPENAI_API_KEY` is configured. Otherwise, the app explicitly returns a fallback response.
- Career recommendations are exploratory guidance, not a guarantee of suitability, employment, or salary.
