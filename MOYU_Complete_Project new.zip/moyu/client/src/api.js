const BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';
export class ApiError extends Error { constructor(message, status) { super(message); this.status = status; } }
async function request(path, { method='GET', body }={}) {
  let res;
  try { res = await fetch(`${BASE}${path}`, { method, credentials:'include', headers: body ? {'Content-Type':'application/json'} : undefined, body: body ? JSON.stringify(body) : undefined }); }
  catch { throw new ApiError('Could not reach the server. Check that the backend is running.', 0); }
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new ApiError(data.error || 'Something went wrong.', res.status);
  return data;
}
export const api = {
 register:(payload)=>request('/auth/register',{method:'POST',body:payload}), login:(payload)=>request('/auth/login',{method:'POST',body:payload}), logout:()=>request('/auth/logout',{method:'POST'}), me:()=>request('/auth/me'),
 getProgress:()=>request('/student/progress'), saveProgress:(payload)=>request('/student/progress',{method:'PUT',body:payload}), saveAssessment:(payload)=>request('/student/assessment',{method:'POST',body:payload}), getAssessment:()=>request('/student/assessment'), askAI:(message,domain)=>request('/ai/chat',{method:'POST',body:{message,domain}})
};
