// Shared frame for login and sign-up, styled with the MOYU brand.
export default function AuthLayout({ eyebrow, title, subtitle, children }) {
  return (
    <div className="auth-page">
      <header className="auth-brand">
        <span className="brand-mark" aria-hidden="true">
          <svg viewBox="0 0 24 24">
            <path d="M12 2l2.4 7.6L22 12l-7.6 2.4L12 22l-2.4-7.6L2 12l7.6-2.4z" />
          </svg>
        </span>
        <span className="brand-word">MOYU</span>
        <span className="brand-tag">Find Your Way.</span>
      </header>

      <main className="auth-card">
        <span className="eyebrow">{eyebrow}</span>
        <h1>{title}</h1>
        <p className="lead">{subtitle}</p>
        {children}
      </main>
    </div>
  );
}
