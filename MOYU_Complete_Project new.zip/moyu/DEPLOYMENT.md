# MOYU deployment guide (Vercel + Render + MongoDB Atlas)

This setup keeps the frontend and API separate. It can be run on free tiers where available, but free-tier limits, sleeping, quotas, and provider terms may change.

## 1. Put the project on GitHub

1. Extract this ZIP.
2. Create a new GitHub repository, for example `moyu-career-compass`.
3. Upload the contents of the `moyu/` folder (so `client/`, `server/`, `README.md`, and `DEPLOYMENT.md` are at repository root).
4. Confirm that no `.env` file or secret key was uploaded. The `.gitignore` prevents common local secret files from being committed.

## 2. Create the MongoDB database

1. Sign in to MongoDB Atlas and create a free cluster if that tier is available to you.
2. Create a database user with a strong password.
3. In Network Access, add the IP access rule required by your hosting setup. For a quick student demo, Atlas may offer an allow-from-anywhere rule (`0.0.0.0/0`); it increases exposure, so use a strong database password and tighten access if your setup permits.
4. Select **Connect → Drivers**, copy the Node.js connection string, and replace the username, password, and database name. Use `moyu` as the database name, e.g. `mongodb+srv://USER:PASSWORD@CLUSTER.mongodb.net/moyu?retryWrites=true&w=majority`.
5. Do not paste the connection string into frontend variables or public code.

## 3. Deploy the backend to Render

1. Sign in to Render and create **New → Web Service** from your GitHub repository.
2. Set **Root Directory** to `server`.
3. Set **Build Command** to `npm install`.
4. Set **Start Command** to `npm start`.
5. Choose a Node runtime if Render asks.
6. In the service's Environment settings, add:
   - `MONGODB_URI` = your Atlas connection string
   - `JWT_SECRET` = a long random secret (generate one locally with `node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"`)
   - `JWT_EXPIRES_IN` = `7d`
   - `NODE_ENV` = `production`
   - `CLIENT_ORIGIN` = temporary value `http://localhost:5173` until Vercel is deployed
   - `OPENAI_API_KEY` = optional; omit it if you do not want to configure a paid/usage-billed AI provider
   - `OPENAI_MODEL` = optional `gpt-4o-mini`
   - `OPENAI_BASE_URL` = optional `https://api.openai.com/v1/chat/completions`
7. Deploy. Copy the service URL, such as `https://your-moyu-api.onrender.com`.
8. Open `https://your-moyu-api.onrender.com/api/health`. It should return `{"ok":true}`. If it does not, check Render logs and confirm `MONGODB_URI` and `JWT_SECRET` are valid.

## 4. Deploy the frontend to Vercel

1. Sign in to Vercel and import the same GitHub repository.
2. Set **Root Directory** to `client`.
3. Framework preset: **Vite** (or let Vercel detect it).
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Add environment variable `VITE_API_BASE_URL` = `https://your-moyu-api.onrender.com/api` (replace with the actual Render URL; do not add a trailing slash after `/api`).
7. Deploy and copy the live frontend URL, such as `https://your-moyu.vercel.app`.

The included `client/vercel.json` rewrites browser routes to `index.html`, so routes such as `/login` continue to work on refresh.

## 5. Connect frontend and backend origins

1. Return to Render → your web service → Environment.
2. Change `CLIENT_ORIGIN` to the exact Vercel origin, e.g. `https://your-moyu.vercel.app` (no path and no trailing slash).
3. Save changes and wait for the service to redeploy.
4. Open the Vercel site and test **Register → Log out → Log in → Assessment → Results → Roadmap → mark a task complete → refresh**.
5. Confirm progress remains after refresh. If login works locally but not in production, verify the exact `CLIENT_ORIGIN`, `VITE_API_BASE_URL`, HTTPS URLs, and browser cookie settings. Because the frontend and API use different hostnames, some privacy settings/extensions may block cross-site cookies; using a custom domain arrangement under the same site can help if this occurs.

## 6. Optional: enable live AI answers

The AI mentor works with a fallback message even without an API key. To enable live provider answers, create an API key with your chosen AI provider and add it to Render as `OPENAI_API_KEY`. Add usage limits/billing controls at the provider first; API calls may cost money. Never use a secret key in `VITE_...` variables because frontend variables are visible in the browser bundle. Redeploy the backend after setting it.

## 7. Final smoke-test checklist

- [ ] `/api/health` returns `{ "ok": true }`.
- [ ] A new account can be registered.
- [ ] A user can log out and log back in.
- [ ] The four assessment sections validate answers and produce results.
- [ ] Recommended domains open and can be selected.
- [ ] Roadmap task checkboxes update the dashboard percentage.
- [ ] Progress persists after refresh and logging back in.
- [ ] Learning links open their source sites.
- [ ] The mentor shows a fallback if no AI key is set, or a live answer if configured.
- [ ] No `.env`, database password, JWT secret, or AI key is committed to GitHub.

## Troubleshooting

- **CORS error:** `CLIENT_ORIGIN` must exactly match the deployed Vercel origin; save and redeploy Render.
- **API cannot connect to MongoDB:** verify the Atlas connection string, database user/password encoding, and Atlas Network Access rules.
- **Frontend still calls localhost:** add/update `VITE_API_BASE_URL` in Vercel and redeploy the frontend.
- **Login cookie is not retained:** ensure both deployed URLs use HTTPS, `NODE_ENV=production`, and credentials are enabled; test in a normal browser window without privacy extensions. Browser third-party cookie restrictions can affect separate domains.
- **Render's first request is slow:** a free service may have been idle and is starting up; wait briefly and retry.
- **AI mentor error:** verify the provider key, account access, model name and usage limits. The app does not require the AI key for the rest of the site to work.
