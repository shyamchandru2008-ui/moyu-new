import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, minlength: 2, maxlength: 80 },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      maxlength: 254,
    },
    // bcrypt hash only. The plaintext password is never stored.
    passwordHash: { type: String, required: true, select: false },
    role: { type: String, enum: ['student', 'admin'], default: 'student' },
    lastLoginAt: { type: Date },
    selectedDomain: { type: String, default: '' },
    completedTasks: { type: [String], default: [] },
    assessment: { type: mongoose.Schema.Types.Mixed, default: null },
  },
  { timestamps: true }
);

// Returns a safe object for API responses (no password hash)
userSchema.methods.toPublic = function toPublic() {
  return {
    id: this._id.toString(),
    name: this.name,
    email: this.email,
    role: this.role,
    createdAt: this.createdAt,
  };
};

export default mongoose.model('User', userSchema);
