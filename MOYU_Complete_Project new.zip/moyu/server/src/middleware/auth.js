import jwt from 'jsonwebtoken';
import User from '../models/User.js';

export const AUTH_COOKIE = 'moyu_token';

// Requires a valid login cookie. Attaches req.user (safe fields only).
export async function requireAuth(req, res, next) {
  try {
    const token = req.cookies?.[AUTH_COOKIE];
    if (!token) {
      return res.status(401).json({ error: 'Please log in to continue.' });
    }

    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.sub);
    if (!user) {
      return res.status(401).json({ error: 'Your session is no longer valid. Please log in again.' });
    }

    req.user = user;
    return next();
  } catch (err) {
    return res.status(401).json({ error: 'Your session has expired. Please log in again.' });
  }
}
