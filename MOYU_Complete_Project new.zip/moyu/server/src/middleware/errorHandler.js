// Central error handler. Keeps internal details out of responses.
export function notFound(req, res) {
  res.status(404).json({ error: 'Route not found.' });
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  const status = err.status || err.statusCode || 500;

  if (status >= 500) {
    console.error('Server error:', err);
    return res.status(500).json({ error: 'Something went wrong on our side. Please try again.' });
  }

  return res.status(status).json({ error: err.message || 'Request failed.' });
}
