import 'dotenv/config';
import express from 'express';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import helmet from 'helmet';
import { connectDB } from './config/db.js';
import authRoutes from './routes/auth.js';
import studentRoutes from './routes/student.js';
import aiRoutes from './routes/ai.js';
import { notFound, errorHandler } from './middleware/errorHandler.js';

const app = express();
const PORT = process.env.PORT || 5000;

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.startsWith('replace_with')) {
  throw new Error('JWT_SECRET is missing or still the placeholder. Set a real value in server/.env');
}

app.set('trust proxy', 1); // required behind Render/Railway so rate limiting sees the real client IP
app.use(helmet());
app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());

app.use(
  cors({
    origin: process.env.CLIENT_ORIGIN, // exact frontend origin only
    credentials: true, // needed so the browser sends the login cookie
  })
);

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api/auth', authRoutes);
app.use('/api/student', studentRoutes);
app.use('/api/ai', aiRoutes);

app.use(notFound);
app.use(errorHandler);

connectDB()
  .then(() => {
    app.listen(PORT, () => console.log(`API listening on port ${PORT}`));
  })
  .catch((err) => {
    console.error('Failed to start server:', err.message);
    process.exit(1);
  });
