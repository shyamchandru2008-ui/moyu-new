import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import rateLimit from 'express-rate-limit';
import { body, validationResult } from 'express-validator';
import User from '../models/User.js';
import { AUTH_COOKIE, requireAuth } from '../middleware/auth.js';

const router = Router();

// A real bcrypt hash used when an email is not registered, so login takes similar time either way.
const DUMMY_HASH = bcrypt.hashSync('moyu-dummy-password', 12);

// Strict limit on login and sign-up to slow down password guessing and bulk account creation.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts. Please wait 15 minutes and try again.' },
});

const isProd = process.env.NODE_ENV === 'production';

function issueSession(res, user) {
  const token = jwt.sign({ sub: user._id.toString() }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });

  res.cookie(AUTH_COOKIE, token, {
    httpOnly: true, // not readable by JavaScript in the browser
    secure: isProd, // HTTPS only in production
    // The frontend and API live on different domains in production, so cross-site cookies are needed.
    sameSite: isProd ? 'none' : 'lax',
    maxAge: 7 * 24 * 60 * 60 * 1000,
    path: '/',
  });
}

function validationFailed(req, res) {
  const result = validationResult(req);
  if (result.isEmpty()) return false;
  res.status(400).json({ error: result.array()[0].msg });
  return true;
}

// POST /api/auth/register
router.post(
  '/register',
  authLimiter,
  [
    body('name')
      .trim()
      .isLength({ min: 2, max: 80 })
      .withMessage('Please enter your name (2 to 80 characters).'),
    body('email')
      .trim()
      .isEmail()
      .withMessage('Please enter a valid email address.')
      .isLength({ max: 254 })
      .normalizeEmail({ gmail_remove_dots: false }),
    body('password')
      .isLength({ min: 8, max: 72 })
      .withMessage('Password must be between 8 and 72 characters.')
      .matches(/[A-Za-z]/)
      .withMessage('Password must include at least one letter.')
      .matches(/[0-9]/)
      .withMessage('Password must include at least one number.'),
    body('confirmPassword')
      .custom((value, { req }) => value === req.body.password)
      .withMessage('Passwords do not match.'),
  ],
  async (req, res, next) => {
    try {
      if (validationFailed(req, res)) return;

      const { name, email, password } = req.body;

      const existing = await User.findOne({ email });
      if (existing) {
        // Generic message keeps the response from confirming which emails are registered.
        // Still a clear message for the student, so they know to log in instead.
        return res
          .status(409)
          .json({ error: 'An account with this email already exists. Please log in instead.' });
      }

      const passwordHash = await bcrypt.hash(password, 12);
      const user = await User.create({ name, email, passwordHash });

      issueSession(res, user);
      return res.status(201).json({ user: user.toPublic() });
    } catch (err) {
      // Race condition: two sign-ups with the same email at once
      if (err.code === 11000) {
        return res
          .status(409)
          .json({ error: 'An account with this email already exists. Please log in instead.' });
      }
      return next(err);
    }
  }
);

// POST /api/auth/login
router.post(
  '/login',
  authLimiter,
  [
    body('email').trim().isEmail().withMessage('Please enter a valid email address.'),
    body('password').isString().notEmpty().withMessage('Please enter your password.'),
  ],
  async (req, res, next) => {
    try {
      if (validationFailed(req, res)) return;

      const email = req.body.email.trim().toLowerCase();
      const { password } = req.body;

      const user = await User.findOne({ email }).select('+passwordHash');

      // Same message for "no account" and "wrong password" to avoid revealing registered emails.
      const invalid = { status: 401, message: 'Email or password is incorrect.' };
      if (!user) {
        // Run a dummy comparison so response timing does not reveal whether the email exists.
        await bcrypt.compare(password, DUMMY_HASH);
        return res.status(401).json({ error: invalid.message });
      }

      const matches = await bcrypt.compare(password, user.passwordHash);
      if (!matches) {
        return res.status(401).json({ error: invalid.message });
      }

      user.lastLoginAt = new Date();
      await user.save();

      issueSession(res, user);
      return res.json({ user: user.toPublic() });
    } catch (err) {
      return next(err);
    }
  }
);

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  res.clearCookie(AUTH_COOKIE, {
    httpOnly: true,
    secure: isProd,
    sameSite: isProd ? 'none' : 'lax',
    path: '/',
  });
  return res.json({ ok: true });
});

// GET /api/auth/me  (used on page load to restore the session)
router.get('/me', requireAuth, (req, res) => {
  return res.json({ user: req.user.toPublic() });
});

export default router;
