import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
const router=Router();
router.post('/chat', requireAuth, async (req,res)=>{
 const message=String(req.body?.message || '').trim().slice(0,3000); const domain=String(req.body?.domain || req.user.selectedDomain || 'career exploration').slice(0,100);
 if(!message) return res.status(400).json({error:'Please enter a question.'});
 if(!process.env.OPENAI_API_KEY) return res.json({answer:`I'm MOYU Career Mentor, your guide for ${domain}. The AI provider is not configured yet, so I can offer a starter guide: identify the skills this domain uses, learn the foundations, practice with small projects, and build a portfolio.\n\nYour question: “${message}”\n\nTo enable live AI answers, add OPENAI_API_KEY to the backend environment. Until then, this is a fallback response, not a generated AI answer.` ,configured:false});
 try { const response=await fetch(process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify({model:process.env.OPENAI_MODEL || 'gpt-4o-mini',messages:[{role:'system',content:`You are MOYU Career Mentor. Give practical, beginner-friendly and honest career guidance about ${domain}. Explain steps, recommend skills and projects, avoid guarantees about jobs, and say when information needs verification.`},{role:'user',content:message}],temperature:0.5})}); const data=await response.json(); if(!response.ok) return res.status(502).json({error:'The AI provider could not answer right now. Check the backend AI configuration.'}); res.json({answer:data.choices?.[0]?.message?.content || 'No answer was returned.',configured:true}); }
 catch { res.status(502).json({error:'Could not connect to the AI provider. Please try again later.'}); }
});
export default router;
