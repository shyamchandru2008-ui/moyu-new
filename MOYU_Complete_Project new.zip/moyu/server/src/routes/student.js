import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
const router = Router();
router.use(requireAuth);
router.get('/progress', (req,res) => res.json({ selectedDomain:req.user.selectedDomain || '', completedTasks:req.user.completedTasks || [], assessment:req.user.assessment || null }));
router.put('/progress', async (req,res,next) => { try {
 const selectedDomain = typeof req.body.selectedDomain === 'string' ? req.body.selectedDomain.slice(0,100) : req.user.selectedDomain;
 const completedTasks = Array.isArray(req.body.completedTasks) ? [...new Set(req.body.completedTasks.filter(x=>typeof x==='string').map(x=>x.slice(0,180)))].slice(0,500) : req.user.completedTasks;
 req.user.selectedDomain=selectedDomain; req.user.completedTasks=completedTasks; await req.user.save(); res.json({selectedDomain:req.user.selectedDomain,completedTasks:req.user.completedTasks});
} catch(e){next(e)} });
router.get('/assessment', (req,res)=>res.json({assessment:req.user.assessment || null}));
router.post('/assessment', async (req,res,next)=>{try { const {answers,results}=req.body; if(!answers || typeof answers!=='object' || !Array.isArray(results)) return res.status(400).json({error:'Assessment answers and results are required.'}); req.user.assessment={answers,results:results.slice(0,3),completedAt:new Date()}; if(results[0]?.domain) req.user.selectedDomain=String(results[0].domain).slice(0,100); await req.user.save(); res.json({assessment:req.user.assessment,selectedDomain:req.user.selectedDomain}); } catch(e){next(e)} });
export default router;
